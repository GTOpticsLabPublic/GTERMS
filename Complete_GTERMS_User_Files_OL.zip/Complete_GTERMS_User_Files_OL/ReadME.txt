Version Number: 6.0
Version Date: 27-May-2024

Changelogs:
Version-5.0 of IEEE_GT_OL.ens
Version-6.0 of BibTex_Export_GT_OL.ens
Version-4.0 of Reference_Types_GT_OL.xml
Version-1.0 of Examples-Reference-Types.pdf