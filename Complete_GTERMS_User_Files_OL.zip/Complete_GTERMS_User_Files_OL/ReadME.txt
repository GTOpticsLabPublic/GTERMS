Version Number: 7.2
Version Date: 25-October-2024

Changelogs - 7.2:
Version-7.0 of IEEE_GTERMS.ens
Version 7.0 of BibTex_Export_GTERMS.ens
Version-6.0 of Reference_Types_GTERMS.xml
Updates to ALL user documentation/instruction files
Renaming of files from GT_OL format to GTERMS

Changelogs - 7.1:
Updated Examples-Reference-Types.pdf with 'Program' and 2 examples per reference type.

Changelogs - 7.0:
Version-6.0 of IEEE_GT_OL.ens
Version-6.0 of BibTex_Export_GT_OL.ens
Version-5.0 of Reference_Types_GT_OL.xml
Version-2.0 of Examples-Reference-Types.pdf