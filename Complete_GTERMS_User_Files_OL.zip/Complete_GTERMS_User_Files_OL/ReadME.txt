Version Number: 7.1
Version Date: 11-October-2024

Changelogs (For 7.1):
Updated Examples-Reference-Types.pdf with 'Program' and 2 examples per reference type.

Changelogs (For 7.0):
Version-6.0 of IEEE_GT_OL.ens
Version-6.0 of BibTex_Export_GT_OL.ens
Version-5.0 of Reference_Types_GT_OL.xml
Version-2.0 of Examples-Reference-Types.pdf