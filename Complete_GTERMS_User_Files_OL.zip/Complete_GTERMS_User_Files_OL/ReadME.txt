Version Number: 7.0
Version Date: 11-October-2024

Changelogs:
Version-6.0 of IEEE_GT_OL.ens
Version-6.0 of BibTex_Export_GT_OL.ens
Version-5.0 of Reference_Types_GT_OL.xml
Version-2.0 of Examples-Reference-Types.pdf