For installation instructions, please refer to the "Instructions" folder. If you experience any installation issues, refer to the "GTERMS Documentation.pdf" file within the "Documentation" folder.


-X-X-X-X-X-X-X-X-

Version Number: 7.4
Version Date: 10-January-2025

Changelogs - 7.4:
All filenames update to use hyphens instead of underscores.
Documentation Update for concision.
Version-9.0 of IEEE_GTERMS.ens
Version 9.0 of BibTex_Export_GTERMS.ens
Version-8.0 of Reference_Types_GTERMS.xml

Changelogs - 7.3:
Version-8.0 of IEEE_GTERMS.ens
Version 8.0 of BibTex_Export_GTERMS.ens
Version-7.0 of Reference_Types_GTERMS.xml
Changed some documentation to switch from "Clip Art and Stock Image" to "Clip Art or Stock Image"

Changelogs - 7.2:
Version-7.0 of IEEE_GTERMS.ens
Version 7.0 of BibTex_Export_GTERMS.ens
Version-6.0 of Reference_Types_GTERMS.xml
Updates to ALL user documentation/instruction files
Renaming of files from GT_OL format to GTERMS

Changelogs - 7.1:
Updated Examples-Reference-Types.pdf with 'Program' and 2 examples per reference type.

Changelogs - 7.0:
Version-6.0 of IEEE_GT_OL.ens
Version-6.0 of BibTex_Export_GT_OL.ens
Version-5.0 of Reference_Types_GT_OL.xml
Version-2.0 of Examples-Reference-Types.pdf